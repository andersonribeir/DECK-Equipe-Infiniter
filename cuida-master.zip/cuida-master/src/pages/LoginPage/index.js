import React from 'react';

import { Container, Content } from './styles';

function Login() {
  return (
    <Container>
      <Content >
        Teste
      </Content>
    </Container>
  );
}

export default Login;
